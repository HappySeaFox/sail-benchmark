                #include <stdlib.h>
                #include <string.h>
                #include <tiffio.h>

                int main(int argc, char *argv[]) {

                    TIFF *tiff = TIFFOpen("file.tiff", "w");

                    if (tiff == NULL) {
                        return 1;
                    }

                    TIFFSetField(tiff, TIFFTAG_IMAGEWIDTH,  1);
                    TIFFSetField(tiff, TIFFTAG_IMAGELENGTH, 1);
                    TIFFSetField(tiff, TIFFTAG_ORIENTATION, ORIENTATION_TOPLEFT);
                    TIFFSetField(tiff, TIFFTAG_SAMPLESPERPIXEL, 4);
                    TIFFSetField(tiff, TIFFTAG_BITSPERSAMPLE, 8);
                    TIFFSetField(tiff, TIFFTAG_PLANARCONFIG, PLANARCONFIG_CONTIG);
                    TIFFSetField(tiff, TIFFTAG_PHOTOMETRIC, PHOTOMETRIC_RGB);
                    TIFFSetField(tiff, TIFFTAG_COMPRESSION, COMPRESSION_JPEG);
                    TIFFSetField(tiff, TIFFTAG_ROWSPERSTRIP, TIFFDefaultStripSize(tiff, (uint32)-1));

                    unsigned char *scan = malloc(4);
                    memset(scan, 255, 4);

                    if (TIFFWriteScanline(tiff, scan, 0, 0) < 0) {
                        fprintf(stderr, "TIFFWriteScanline FAILED\n");
                        return 2;
                    }

                    TIFFClose(tiff);

                    free(scan);

                    fprintf(stderr, "ZERO RETURN\n");

                    return 0;
                }
