## Priority 1

- remove SAIL_CHECK_xxx checks in codecs? Are they needed? libsail does them as well

- gamma in sail_image

- background color in sail_image

## Priority 2

- Print more errors on 'return SAIL_ERROR_XXX'

- initializer lists in C++

## Priority 3

- only-, except- cmake runtime defines for bindings ?

- document how SAIL uses codecs APIs

- enum class in C++?
