# Extra libs for SAIL needed on specific platforms

* `pkg-config`: from [https://sourceforge.net/projects/pkgconfiglite](https://sourceforge.net/projects/pkgconfiglite)
* `nasm`: from [https://www.nasm.us](https://www.nasm.us)
* `zlib-ng`: from [https://github.com/zlib-ng/zlib-ng](https://github.com/zlib-ng/zlib-ng)
* `zstd`: from [https://github.com/facebook/zstd](https://github.com/facebook/zstd)
* `jbigkit`: from [https://www.cl.cam.ac.uk/~mgk25/jbigkit](https://www.cl.cam.ac.uk/~mgk25/jbigkit)
* `libjpeg-turbo`: from [https://sourceforge.net/projects/libjpeg-turbo](https://sourceforge.net/projects/libjpeg-turbo)
* `libpng`: from [http://www.libpng.org/pub/png/libpng.html](http://www.libpng.org/pub/png/libpng.html)
* `libtiff`: from [http://simplesystems.org/libtiff](http://simplesystems.org/libtiff)
* `giflib`: from [https://sourceforge.net/projects/giflib](https://sourceforge.net/projects/giflib)
